﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace quanLyKhachSan.module
{
    public class HoaDon
    {
        String t_khang, n_vao, g_vao, s_gio, s_tien, t_nv,t_phong, t_tang, d_vu, id_phong, id_tkhoan, id_hoaDon;

        public string T_khang { get => t_khang; set => t_khang = value; }
        public string N_vao { get => n_vao; set => n_vao = value; }
        public string G_vao { get => g_vao; set => g_vao = value; }
        public string S_gio { get => s_gio; set => s_gio = value; }
        public string S_tien { get => s_tien; set => s_tien = value; }
        public string T_nv { get => t_nv; set => t_nv = value; }
        public string T_phong { get => t_phong; set => t_phong = value; }
        public string T_tang { get => t_tang; set => t_tang = value; }
        public string D_vu { get => d_vu; set => d_vu = value; }
        public string Id_phong { get => id_phong; set => id_phong = value; }
        public string Id_tkhoan { get => id_tkhoan; set => id_tkhoan = value; }
        public string Id_hoaDon { get => id_hoaDon; set => id_hoaDon = value; }
    }
}
